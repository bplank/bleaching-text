#!/bin/bash
#
# prepare json files for experiments (pre-processed)
# 
META_LOC="data/twisty-2016-02-metadata/"  # location to meta-data (gender, mbti) for each user
OUT_DIR="preprocessed-twisty-non-tokenized/"

mkdir -p $OUT_DIR

for LANGUAGE in "EN" #"NL" "FR" "PT" "ES"
do
    TWEETS_LOC="data/tweets_2016/${LANGUAGE}/users_id"  # location to json files with tweets, one file per user

    for n in 200 # tweets/user
    do
	python src/prepare_data.py --num-tweets $n --language ${LANGUAGE} ${META_LOC}/TwiSty-${LANGUAGE}.json $TWEETS_LOC $OUT_DIR
    done
done


