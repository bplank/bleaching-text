###### library for preprocessing tweets

#from tinytokenizer import TinyTokenizer
from nltk.tokenize import TweetTokenizer

class Preprocessor:
    
    def __init__(self,delimiter=" "):
        # delimiter to split tweets into tokens
        self.DELIM=delimiter
        self.tokenizer= TweetTokenizer()

    def replace_hashtags_urls_user_mentions_and_tokenize(self, text):
        """
        Replace hashtags, URLS and user mentions with placeholders and tokenize
        :param text:
        :return:
        >>> p=Preprocessor()
        >>> p.replace_hashtags_urls_user_mentions_and_tokenize("Dit was een kwestie van tijd . Hierna gaan hipsters de VHS weer hip maken . https://t.co/HaOCCV94cR")
        'Dit was een kwestie van tijd . Hierna gaan hipsters de VHS weer hip maken . URL'
        """
        text = self.remove_whitespace(text)
        text = self.replace_hashtags(text)
        return self.replace_urls_user_mentions_and_tokenize(text)

    def remove_whitespace(self, text):
        text = text.strip()
        text = text.replace("\n", " ")
        return text.replace("\t", " ")

    def replace_urls_user_mentions_and_tokenize(self, text):
        text = self.remove_whitespace(text)
        text = self.replace_urls(text)
        #text = self.tokenize(text)
        return self.replace_user_tags(text)

    def tokenize(self,tweet):
        return " ".join(self.tokenizer.tokenize(tweet))

    def replace_user_tags(self,tweet,remove=False):
        """
        Replace mentions to usernames with "USER"
        if remove=True removes the user mentions
        
        >>> p=Preprocessor()
        >>> p.replace_user_tags("@maya yes this is cool1@ did b@ @augyyz")
        'USER yes this is cool1@ did b@ USER'
        >>> p.replace_user_tags("@maya yes this is cool1@ did b@ @augyyz",remove=True)
        'yes this is cool1@ did b@'
        """
        if remove:
            return self.DELIM.join([w for w in tweet.split(self.DELIM) if not w.startswith("@")])
        else:
            return self.DELIM.join(["USER" if w.startswith("@") else w for w in tweet.split(self.DELIM)])

    def replace_urls(self,tweet,remove=False):
        """
        Replace urls with URL
        if remove=True removes them
    
        >>> p=Preprocessor()
        >>> p.replace_urls("@maya yes this is cool1@ did b@ @augyyz http://www.bitly")
        '@maya yes this is cool1@ did b@ @augyyz URL'
        >>> p.replace_urls("@maya yes this is cool1@ did b@ @augyyz http://www.bitly",remove=True)
        '@maya yes this is cool1@ did b@ @augyyz'
        >>> p.replace_urls("Dit was een kwestie van tijd . Hierna gaan hipsters de VHS weer hip maken . https://t.co/HaOCCV94cR")
        'Dit was een kwestie van tijd . Hierna gaan hipsters de VHS weer hip maken . URL'
        
        """
        if remove:
            return self.DELIM.join([w for w in tweet.split(self.DELIM) if not "http" in w])
        else:
            return self.DELIM.join(["URL" if "http" in w else w for w in tweet.split(self.DELIM)])

    def replace_hashtags(self,tweet,remove=False):
        """
        Replace hashtags with HASHTAG
        if remove=True removes them (any number of # at token start)

        >>> p=Preprocessor()
        >>> p.replace_hashtags("yes #cool we are in #miami ###yes")
        'yes HASHTAG we are in HASHTAG HASHTAG'
        >>> p.replace_hashtags("yes #cool we# are in #miami ###yes",remove=True)
        'yes we# are in'
        """
        if remove:
            return self.DELIM.join([w for w in tweet.split(self.DELIM) if not w.startswith("#")])
        else:
            return self.DELIM.join(["HASHTAG" if w.startswith("#") else w for w in tweet.split(self.DELIM)])

    def remove_mbti(self,tweet,remove=False):
        """
        removes MBTI tokens from tweet
        >>> p=Preprocessor()
        >>> p.remove_mbti("this is a test")
        'this is a test'
        >>> p.remove_mbti("I got intj !")
        'I got !'
        """
        MBTI_TYPES=["ENFJ", "ENTJ", "ENTP", "ESFJ", "ESFP", "ESTJ", "INFJ", "INFP", "INTJ", "INTP", "ISFJ", "ISTJ", "ISTP"]

        return self.DELIM.join([w for w in tweet.split(self.DELIM) if w.upper() not in MBTI_TYPES])

if __name__ == "__main__":
    import doctest
    doctest.testmod()
