import json
import sys
import random
from collections import Counter
import numpy as np

seed = 123

if len(sys.argv) < 2:
  print('please specify target file')
  exit(0)

finalData = {}
data = json.load(open(sys.argv[1]))

total_tweets = len(data["tweets"])

labels=np.array(data['gender'])
instances=np.array(data['tweets'])

min_class=Counter(labels).most_common(n=len(labels))[-1][0]
print(min_class)
freq_min_class=Counter(labels)[min_class]
print(min_class, freq_min_class, Counter(labels))

## first shuffle instances
random.seed(seed)
random.shuffle(instances)
random.seed(seed)
random.shuffle(labels)

print("downsample majority class to minority class frequency")

indices_max_class = [index for index in list(range(0, len(labels))) if labels[index] != min_class]
# sample
selected_max_indices = np.random.choice(indices_max_class, freq_min_class, replace=False)

# keep all
indices_min_class = [index for index in list(range(0, len(labels))) if labels[index] == min_class]

print("num max class", len(indices_max_class))
print("selected", len(selected_max_indices))

## all_selected:
## original min_freq labels
## and sampled max_freq labels
all_selected = list(indices_min_class) + list(selected_max_indices)

#sample = instances[0:i]
finalData['gender'] = list(labels[all_selected] )
finalData['tweets'] = list(instances[all_selected])

assert len(finalData["gender"]) == len(finalData["tweets"])
print("balanced: ", Counter(finalData["gender"]))

json.dump(finalData, open(sys.argv[1]+".balanced", 'w'))
