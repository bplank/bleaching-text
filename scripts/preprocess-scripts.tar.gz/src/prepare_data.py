__author__ = 'bplank'

import json
import argparse
import random
import codecs
import os
import sys
from preproc import Preprocessor
import numpy as np

parser = argparse.ArgumentParser(description="Preparing TwiSty data for experiments")
parser.add_argument('--language', help="language id", choices=("NL", "DE", "IT", "EN", "FR", "PT", "ES"))
parser.add_argument('data', help="data, e.g. TwiSty-EN.json")
parser.add_argument('user_dir', help="user_dir, e.g. data/tweets/en/users_id/")
parser.add_argument('output_dir', help="output dir for json file")
parser.add_argument('--seed', help="random seed",type=int,default=0)
parser.add_argument('--num-tweets', help="number of tweets per user (default: 200)", default=200, type=int)
parser.add_argument('--img', help="image data (use only userids that also have an image info)")
parser.add_argument('--preproc', help="choice of pre-processing", choices=("URL+HASHTAG+USER", "URL+USER"), default="URL+USER")
parser.add_argument('--keep-org', help="keep also original tweets", default=False, action="store_true")

args = parser.parse_args()


def read_data_file(args):
    ## the two output json files
    output_json = {}
    log_sampled_tweets = {}

    all_tok_list_of_tweets = [] # keep tweets as separate lists
    all_org_list_of_tweets = []  # original
    mbti_labels=[]
    gender_labels = []

    user_ids = []

    author_profiles = json.load(codecs.open(args.data, encoding="utf-8"))

    if args.img:
        user_ids_with_img = [line.strip().split()[0] for line in open(args.img).readlines()]
        print("users with images: {}".format(len(user_ids_with_img), file=sys.stderr))
        all=set(author_profiles.keys())
        print("remain: {}".format(len(all.intersection(set(user_ids_with_img)))))

    preprocessor = Preprocessor()

    if args.preproc == "URL+HASHTAG+USER":
        preprocess = preprocessor.replace_hashtags_urls_user_mentions_and_tokenize  #actually non tokenization is disabled
    elif args.preproc == "URL+USER":
        preprocess = preprocessor.replace_urls_user_mentions_and_tokenize

    for user_id in author_profiles:
        user_tweets_tok=[]
        user_tweets_org = []
        if args.img:
            if str(user_id) not in user_ids_with_img:
              print("skip user", user_id, file=sys.stderr)
              continue
        user_ids.append(user_id)

        if len(author_profiles[user_id]["confirmed_tweet_ids"]) >=args.num_tweets:
            sampled_tweets = random.sample(author_profiles[user_id]["confirmed_tweet_ids"], args.num_tweets)
            log_sampled_tweets[user_id] = sampled_tweets
            try:
                print(args.user_dir, user_id)
                user_data = json.load(codecs.open("{}/{}.json".format(args.user_dir, user_id), encoding="utf-8"))
            except Exception as e:
                print(getattr(e, 'message', repr(e)))
                print("skipping problematic user id:", user_id)
                continue
            # get text of sampled tweets and tokenize
            print(user_id, len(user_data['tweets']))
            for tweet_id in sampled_tweets:
                tweet_id = str(tweet_id)
                if tweet_id in user_data['tweets']:
#            for tweet_id in user_data['tweets']:
#                if tweet_id in sampled_tweets:
                    tok_tweet = preprocess(user_data['tweets'][tweet_id]['text'])
                    user_tweets_tok.append(tok_tweet)
                    if "http" in tok_tweet:
                        print("Problem with tweet: ")
                        print("tokenized:", tok_tweet)
                        print("org", user_data['tweets'][tweet_id]['text'])
                        exit()
                    user_tweets_org.append(user_data['tweets'][tweet_id]['text'])
                #else:
                #    print("ohoh should not be here!", tweet_id)
                #    exit()
            if len(user_tweets_org) != args.num_tweets:
                print("skipping user tweets somehow do not match")
                print(len(author_profiles[user_id]["confirmed_tweet_ids"]))
                print(len(sampled_tweets))
                continue
            all_tok_list_of_tweets.append(" NEWLINE ".join(user_tweets_tok))
            all_org_list_of_tweets.append(user_tweets_org)
            

            mbti_labels.append(author_profiles[user_id]['mbti'])
            gender_labels.append(author_profiles[user_id]['gender'])

    assert(len(all_tok_list_of_tweets)==len(mbti_labels))
    print("num users: {}".format(len(mbti_labels)), file=sys.stderr)
    # create output json file
    #output_json["mbti_labels"] = mbti_labels
    output_json["gender"] = gender_labels
    output_json["tweets"] = all_tok_list_of_tweets
    if args.keep_org:
        output_json["org_tweet_list_per_user"] = all_tok_list_of_tweets
    output_json["user_ids"] = user_ids

    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
    json.dump(log_sampled_tweets, open("{1}/{0}-log_sampled_{2}tweets.json".format(args.language, args.output_dir, args.num_tweets),"w"))
    json.dump(output_json, codecs.open("{1}/{0}-data-{2}tweets.json".format(args.language, args.output_dir, args.num_tweets),"w", encoding="utf-8"))


np.random.seed(args.seed)
random.seed(args.seed)
read_data_file(args)
print("data file created")
