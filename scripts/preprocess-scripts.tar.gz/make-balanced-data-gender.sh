#!/bin/bash
#
# prepare json files for experiments (pre-processed)
# 
OUT_DIR="preprocessed-twisty-non-tokenized/"

mkdir -p $OUT_DIR


for file in $OUT_DIR/*data*json
do
    echo $file
    python src/balance.py $file
done
mkdir -p gender-fading-features/data_balanced_non_tokenized
cp $OUT_DIR/*balanced*  gender-fading-features/data_balanced_non_tokenized
