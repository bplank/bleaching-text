# prefix tokens with language code
# suboptimal as we do not tokenize..
# ignore USER and URL
import codecs
import sys
import json
from collections import Counter
import os

filename=sys.argv[1]
filenameout=sys.argv[2]
language = os.path.basename(filename).split("-")[0].lower()
print(language)

data = json.load(codecs.open(filename, encoding="utf-8"))
print("File {} has {} users".format(sys.argv[1], len(data["gender"])))

TWEET_SEP=" NEWLINE "
EXCEPTIONS=["USER", "URL"]

def prefix(tweet,lang):
    return [ "{}:{}".format(lang,w) if w not in EXCEPTIONS else str(w) for w in tweet.split()]

tweets_prefixed = []
for tweets in data["tweets"]:
    tweets = tweets.split(TWEET_SEP)
    tweets = [" ".join(prefix(t, language)) for t in tweets]
#    print(tweets[0])
    tweets_of_user = TWEET_SEP.join(tweets)
    tweets_prefixed.append(tweets_of_user)

out = {}
out["gender"] = data["gender"]
out["tweets"] = tweets_prefixed

assert(len(tweets_prefixed)==len(data["tweets"]))

with codecs.open(filenameout, 'w',encoding='utf-8') as outfile:
    json.dump(out, outfile)
