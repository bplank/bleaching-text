# map all embeddings to the english space

#EDIR=/net/shared/bplank/embeds/poly_a/
EDIR=/net/shared/bplank/gender/embeds_rob/

DIM=100
#for language in en nl fr pt es
#do
#    cp $EDIR/$language.$DIM.txt .
#done

python align.py $EDIR/es.$DIM.txt $EDIR/en.$DIM.txt casa house
cat $EDIR/en.$DIM.txt.mapped $EDIR/es.$DIM.txt.mapped > $EDIR/en+es.$DIM.txt

python align.py $EDIR/nl.$DIM.txt $EDIR/en.$DIM.txt huis house
cat $EDIR/en.$DIM.txt.mapped $EDIR/nl.$DIM.txt.mapped > $EDIR/en+nl.$DIM.txt
cat $EDIR/en+es.$DIM.txt $EDIR/nl.$DIM.txt.mapped > $EDIR/en+es+nl.$DIM.txt

python align.py $EDIR/fr.$DIM.txt $EDIR/en.$DIM.txt maison house
cat $EDIR/en.$DIM.txt.mapped $EDIR/fr.$DIM.txt.mapped > $EDIR/en+fr.$DIM.txt
cat $EDIR/en+es+nl.$DIM.txt $EDIR/fr.$DIM.txt.mapped > $EDIR/en+es+nl+fr.$DIM.txt

python align.py $EDIR/pt.$DIM.txt $EDIR/en.$DIM.txt casa house
cat $EDIR/en.$DIM.txt.mapped $EDIR/pt.$DIM.txt.mapped > $EDIR/en+pt.$DIM.txt
cat $EDIR/en+es+nl+fr.$DIM.txt $EDIR/pt.$DIM.txt.mapped > $EDIR/en+es+nl+fr+pt.$DIM.txt

rm $EDIR/*.mapped
rm $EDIR/en+es.$DIM.txt
rm $EDIR/en+nl.$DIM.txt
rm $EDIR/en+es+nl.$DIM.txt
rm $EDIR/en+fr.$DIM.txt
rm $EDIR/en+es+nl+fr.$DIM.txt
rm $EDIR/en+pt.$DIM.txt





