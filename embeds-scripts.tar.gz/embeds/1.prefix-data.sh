mkdir -p prefixed
for lang in NL ES PT FR EN
do
    python prefix-data.py /net/shared/bplank/gender/data_balanced_non_tokenized/$lang-data-200tweets.json.balanced prefixed/$lang-data-200tweets.json.balanced
done
