#### see https://arxiv.org/abs/1702.03859

import numpy as np
import sys
import codecs

vector_file1=sys.argv[1]
vector_file2=sys.argv[2]

w1=sys.argv[3]
w2=sys.argv[4]


lang2 = vector_file2.split(".")[0]

class Vec:
    def __init__(self, vector_file):
        self.lang = vector_file.split(".")[0]
        
        self.word2id = {}
        with codecs.open(vector_file, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                pass
        elems = line.strip().split(' ')
        num_words = i + 1
        num_dim = len(elems[1:])
        print(num_words, num_dim)
        self.embed = np.zeros((num_words, num_dim))        
        with codecs.open(vector_file, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                elems = line.strip().split(' ')
                vec = [float(x) for x in elems[1:]]
                if len(vec) == num_dim:
                    self.word2id[elems[0]] = i
                    self.embed[i] = vec

    @classmethod
    def cosine_similarity(cls, vec_a, vec_b):
        """Compute cosine similarity between vec_a and vec_b"""
        return np.dot(vec_a, vec_b) / \
            (np.linalg.norm(vec_a) * np.linalg.norm(vec_b))

    def __contains__(self, key):
        return key in self.word2id

    def __getitem__(self, key):
        return self.embed[self.word2id[key]]

    def savePrefixed(self, outfilename):
        OUT = open(outfilename,"w")
        for word in self.word2id:
            vec = self.embed[self.word2id[word]]
            OUT.write("{} {}\n".format(self.lang+":"+word, " ".join([str(x) for x in vec])))
        OUT.close()

    def apply_transform(self, transform):
        """
        Apply the given transformation to the vector space
        Right-multiplies given transform with embeddings E:
            E = E * transform
        Transform can either be a string with a filename to a
        text file containing a ndarray (compat. with np.loadtxt)
        or a numpy ndarray.
        """
        transmat = np.loadtxt(transform) if isinstance(transform, str) else transform
        self.embed = np.matmul(self.embed, transmat)

v1 = Vec(vector_file1)
v2 = Vec(vector_file2)

#print(Vec.cosine_similarity(v1['friend'], v2['amigo']))
print(Vec.cosine_similarity(v1[w1], v2[w2]))

ru_words = set(v1.word2id.keys())
fr_words = set(v2.word2id.keys())
overlap = list(ru_words & fr_words)
bilingual_dictionary = [(entry, entry) for entry in overlap]

print("overlap:", len(overlap))


def normalized(a, axis=-1, order=2):
    """Utility function to normalize the rows of a numpy array."""
    l2 = np.atleast_1d(np.linalg.norm(a, order, axis))
    l2[l2==0] = 1
    return a / np.expand_dims(l2, axis)

def make_training_matrices(source_dictionary, target_dictionary, bilingual_dictionary):
    """
    Source and target dictionaries are the FastVector objects of
    source/target languages. bilingual_dictionary is a list of 
    translation pair tuples [(source_word, target_word), ...].
    """
    source_matrix = []
    target_matrix = []

    for (source, target) in bilingual_dictionary:
        if source in source_dictionary and target in target_dictionary:
            source_matrix.append(source_dictionary[source])
            target_matrix.append(target_dictionary[target])

    # return training matrices
    return np.array(source_matrix), np.array(target_matrix)


def learn_transformation(source_matrix, target_matrix, normalize_vectors=True):
    """
    Source and target matrices are numpy arrays, shape
    (dictionary_length, embedding_dimension). These contain paired
    word vectors from the bilingual dictionary.
    """
    # optionally normalize the training vectors
    if normalize_vectors:
        source_matrix = normalized(source_matrix)
        target_matrix = normalized(target_matrix)

    # perform the SVD
    product = np.matmul(source_matrix.transpose(), target_matrix)
    U, s, V = np.linalg.svd(product)

    # return orthogonal transformation which aligns source language to the target
    return np.matmul(U, V)

#Let's align the French vectors to the Russian vectors, using only this "free" dictionary that we acquired without any bilingual expert knowledge.

source_matrix, target_matrix = make_training_matrices(
    v1, v2, bilingual_dictionary)


transform = learn_transformation(source_matrix, target_matrix)
v1.apply_transform(transform)

print(Vec.cosine_similarity(v1[w1], v2[w2]))

v1.savePrefixed(vector_file1+".mapped")
v2.savePrefixed(vector_file2+".mapped") # save english just to have it prefixed
